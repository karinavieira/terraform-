# terraform
Repositório para armazenamento de códigos de Infraestrutura de aprendizado
